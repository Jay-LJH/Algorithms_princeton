import java.util.Iterator;
import java.util.NoSuchElementException;


public class Deque<T> implements Iterable<T> {
    public Deque() {
        array = (T[]) new Object[8];
        start = end = size = 0;
        length = 8;
    }

    public void addFirst(T item) {
        if (item == null) {
            throw new IllegalArgumentException();
        }
        if (start == 0) {
            T[] temp = (T[]) new Object[length * 2];
            arraycopy(array, 0, temp, length, size);
            array = temp;
            start = length - 1;
            size++;
            end += length;
            length = array.length;
            array[start] = item;
        } else {
            start--;
            size++;
            array[start] = item;
        }
    }

    public void addLast(T item) {
        if (item == null) {
            throw new IllegalArgumentException();
        }
        if (end == length) {
            T[] temp = (T[]) new Object[length * 2];
            arraycopy(array, start, temp, start, size);
            array = temp;
            array[end] = item;
            size++;
            end++;
            length = array.length;
        } else {
            array[end] = item;
            end++;
            size++;
        }
    }

    public T removeFirst() {
        if (size == 0) {
            throw new NoSuchElementException();
        }
        if (size > 0) {
            T res = array[start];
            start++;
            size--;
            if (size < (length) / 4) {
                T[] temp = (T[]) new Object[length / 2];
                arraycopy(array, start, temp, start % ((length) / 4), size);
                array = temp;
                start = start % ((length) / 4);
                end = size + start;
                length = array.length;
            }
            return (T) res;
        }
        return null;
    }

    public T removeLast() {
        if (size == 0) {
            throw new NoSuchElementException();
        }
        if (size > 0) {
            T res = array[end - 1];
            end--;
            size--;
            if (size < (length) / 4) {
                T[] temp = (T[]) new Object[length / 2];
                arraycopy(array, start, temp, start % ((length) / 4), size);
                array = temp;
                start = start % ((length) / 4);
                end = size + start;
                length = array.length;
            }
            return (T) res;
        }
        return null;
    }

    public int size() {
        return size;
    }

    public void printDeque() {
        for (int i = 0; i < size; i++) {
            System.out.print(array[start + i] + " ");
        }
        System.out.print("\n");
    }

    public T get(int index) {
        return array[start + index];
    }

    public Iterator<T> iterator() {
        return new Dequeiterator();
    }
    private class Dequeiterator implements Iterator<T>{
        public boolean hasNext(){
        return i < size+start;
        };
        public T next(){
        return array[i++];
        }
        private int i=start;
    }
    public boolean isEmpty() {
        return size() == 0;
    }

    public interface Iterable<T> {
        Iterator<T> iterator();
    }
    public static void main(String[] args){
       Deque<Integer> t = new Deque<>();
        for (int i = 0; i < 10; i++) {
            t.addFirst(i);
            t.addLast(i+10);
        }
        Iterator<Integer> i = t.iterator();
        while (i.hasNext()) {
            System.out.print(i.next());
        }
        t.printDeque();
        System.out.print("\n");
        System.out.println(t.removeFirst());
        System.out.println(t.removeLast());
        i = t.iterator();
        while (i.hasNext()) {
            System.out.print(i.next());
        }
        System.out.print("\n");
    }
    private void arraycopy(T[] src,int t1,T[] dst,int t2,int size){
        for(int i=0;i<size;i++){
            dst[t2+i]=src[t1+i];
        }
    }
    private T[] array;
    private int start;
    private int end;
    private int size;
    private int length;
}
