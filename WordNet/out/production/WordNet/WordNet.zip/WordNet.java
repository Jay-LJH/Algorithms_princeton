import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.List;

public class WordNet {

    // constructor takes the name of the two input files
    public WordNet(String synsets, String hypernyms) {
        check(synsets, hypernyms);
        In in = new In(synsets);
        nouns = new ArrayList<>();
        while (!in.isEmpty()) {
            String line = in.readLine();
            String[] strings = line.split(",");
            nouns.add(strings[1]);
        }

        in = new In(hypernyms);
        graph = new Digraph(nouns.size());
        while (!in.isEmpty()) {
            String line = in.readLine();
            String[] strings = line.split(",");
            for (int i = 1; i < strings.length; i++)
                graph.addEdge(Integer.parseInt(strings[0]), Integer.parseInt(strings[i]));
        }
    }

    // returns all WordNet nouns
    public Iterable<String> nouns() {
        return nouns;
    }

    // is the word a WordNet noun?
    public boolean isNoun(String word) {
        check(word);
        return nouns.contains(word);
    }

    // distance between nounA and nounB (defined below)
    public int distance(String nounA, String nounB) {
        check(nounA, nounB);
        if (!isNoun(nounA) || !isNoun(nounB))
            throw new IllegalArgumentException();
        int v1 = nouns.indexOf(nounA);
        int v2 = nouns.indexOf(nounB);
        SAP s = new SAP(graph);
        return s.length(v1, v2);
    }

    // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
    // in a shortest ancestral path (defined below)
    public String sap(String nounA, String nounB) {
        check(nounA, nounB);
        if (!isNoun(nounA) || !isNoun(nounB))
            throw new IllegalArgumentException();
        int v1 = nouns.indexOf(nounA);
        int v2 = nouns.indexOf(nounB);
        SAP s = new SAP(graph);
        int anc = s.ancestor(v1, v2);
        return nouns.get(anc);
    }

    private void check(Object... args) {
        for (Object o : args)
            if (o == null)
                throw new IllegalArgumentException();
    }

    // do unit testing of this class
    public static void main(String[] args) {
        WordNet wordnet = new WordNet("synsets.txt", "hypernyms");
        Outcast outcast = new Outcast(wordnet);
        for (int t = 2; t < args.length; t++) {
            In in = new In(args[t]);
            String[] nouns = in.readAllStrings();
            StdOut.println(args[t] + ": " + outcast.outcast(nouns));
        }
    }

    private List<String> nouns;
    private Digraph graph;
}