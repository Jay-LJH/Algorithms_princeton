import edu.princeton.cs.algs4.StdStats;
import static edu.princeton.cs.algs4.StdStats.stddev;
import static edu.princeton.cs.algs4.StdRandom.uniformInt;
import static java.lang.Math.sqrt;

public class PercolationStats {
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        int T = Integer.parseInt(args[1]);
        double[] x=new double[T];
        for(int i=0;i<T;i++){
            Percolation p = new Percolation(n);
            while (!p.percolates()) {
                int row = uniformInt(n) + 1;
                int col = uniformInt(n) + 1;
                while (p.isOpen(row, col)) {
                    row = uniformInt(n) + 1;
                    col = uniformInt(n) + 1;
                }
                p.open(row, col);
            }
            x[i]=(double) p.numberOfOpenSites() / (n * n);
            System.out.println((double) p.numberOfOpenSites() / (n * n));
        }
        double dev= stddev(x);
        double mean= StdStats.mean(x);
        double lower=mean-1.96*dev/sqrt(T);
        double upper=mean+1.96*dev/sqrt(T);
        System.out.println("mean                    = "+mean);
        System.out.println("stddev                  = "+dev);
        System.out.println("95% confidence interval = ["+lower+","+upper+"]");

    }
}
